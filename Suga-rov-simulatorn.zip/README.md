# Suga-röv-simulatorn
A eat ass game created using PhaserJs

Play the demo here: (https://eddornelas.github.io/Fruit-Ninja-Game-Demo/)

## Credits

### -- PhaserJs Engine (The Game engine)
PhaserJs
(https://phaser.io/)
